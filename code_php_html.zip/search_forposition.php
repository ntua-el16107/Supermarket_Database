<?php
include "header.html";
?>

<h2>Search for most popular positions in a store</h2>

<form action="search_forposition_result.php">
  <label for="store">Select a store:(*)</label><br>
  <input required type="text" name="store"><br><br>
  <input type="submit" value="Submit">
</form>

<?php
include "footer.html";
?>