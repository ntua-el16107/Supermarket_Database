<?php
include "header.html";

include "connectionphp.php";


$barcodefromform =$_POST["kati1"] ;
$barcodefromform = str_replace(' ', '', $barcodefromform);
$storefromform = $_POST["kati2"];
$storefromform = str_replace(' ', '', $storefromform);

$pricefromfrom =(float)$_POST["current_price"];

$sql5 = "SELECT * FROM has_products WHERE barcode = '$barcodefromform' AND store_id = '$storefromform' ";
$result5 = $conn->query($sql5);
if($result5->num_rows > 0)
{
while($row5 =$result5->fetch_assoc()) {
	if ($row5["current_price"] != $pricefromfrom){
		$sql2 = "SELECT end_date FROM old_price WHERE barcode = '$barcodefromform' AND store_id = '$storefromform' ";
		$resultt = $conn->query($sql2);
		while($row1 = $resultt->fetch_assoc())
      $rowe = $row1['end_date'];
      $rowst = $row5['current_price'];
				$sql3 = "INSERT INTO old_price (store_id, barcode, end_date, start_date, price) VALUES ('$storefromform','$barcodefromform', CURRENT_TIMESTAMP, '$rowe', $rowst )";
				$result3= $conn->query($sql3);
	
	}
}}
$sql = "UPDATE has_products SET current_price =". $pricefromfrom." WHERE barcode='".$barcodefromform."' AND store_id ='". $storefromform."' ";

$result = $conn->query($sql);

$sql1="select * from old_price where barcode = '".$barcodefromform."' AND store_id ='". $storefromform."' ";


$result1= $conn->query($sql1);
if($result1->num_rows > 0){
  echo "<h2>History of old prices for product with barcode: ". $barcodefromform ." in store with id: ".$storefromform. "</h2>";
?>

<table style="width:60%">
  <tr>
    <th>Barcode</th>
    <th>Price</th>
    <th>Start Date</th>    
    <th>End Date</th>
  </tr>

<?php

  while($row = $result1->fetch_assoc()){

  echo '<tr>
    <td>'.$row["barcode"].'</td>
    <td>'.$row["price"].'</td>
    <td>'.$row["start_date"].'</td>
  <td>'  .$row["end_date"]. '</td></tr>' ;
  }
  echo "</table>";
  echo "<br>";
} else{
  echo "<p>No History</p><br><br>";
}

?>
