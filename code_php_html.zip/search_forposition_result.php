<?php
include "header.html";

include "connectionphp.php";

$storefromform = $_GET["store"];

echo "<h2>The most popular positions of products in store with id: ".$storefromform. "</h2>";

$sql = "SELECT has_products.position as mypos, product.barcode, product.product_name as myname, product.category_name, product.store_tag FROM product, has_products, (SELECT barcode, sum(quantity) FROM consists_of GROUP BY barcode) AS top_barcodes(barcode, sumquantity) WHERE product.barcode = top_barcodes.barcode and top_barcodes.barcode = has_products.barcode and '$storefromform' = has_products.store_id ORDER BY sumquantity DESC";

$result = $conn->query($sql);

if($result->num_rows > 0){
?>

<table style="width:60%">
  <tr>
    <th>Position</th>
    <th>Product</th>
  </tr>

<?php

  while($row = $result->fetch_assoc()){

  echo '<tr>
    <td>'.$row["mypos"].'</td>
    <td>'.$row["myname"].'</td>
  </tr>';
  }
  echo "</table>";
  echo "<br>";
} else{
  echo "<p>Has bought no products yet<br><br></p>";
}

?>