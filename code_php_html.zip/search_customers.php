<?php
include "header.html";
?>

<h2>This is a list of all the customers</h2>

<?php

include "connectionphp.php";

$sql = "SELECT * FROM customer";

$result = $conn->query($sql);
if($result->num_rows > 0){

?>

<table style="width:100%">
  <tr>
    <th>Card number</th>
    <th>First name</th> 
    <th>Last name</th>
    <th>Total points</th>
    <th>Street</th>
    <th>Number</th>
    <th>City</th>
    <th>Postal code</th>
    <th>Birth year</th>
    <th>Sex</th>
    <th>SSN</th>
    <th>Family size</th>
    <th>Phone number</th>
  </tr>

<?php
//if($result->num_rows > 0){
  while($row = $result->fetch_assoc()){
    $card_number = $row["card_number"];
  //  echo "card_number: " .'<a href="/search_customers_result.php?card_number='. $card_number .'" style="color: hotpink;">'. $card_number .'</a>'.  ", first_name: " . $row["first_name"]. ", last_name: " . $row["last_name"]. ", total_points: " . $row["total_points"]. ", street: " . $row["street"]. ", number: " . $row["number"]. ", city: " . $row["city"]. ", postal_code: " . $row["postal_code"]. ", birth_year: " . $row["birth_year"].", sex: " . $row["sex"]. ", SSN: " . $row["SSN"]. ", family_size: " . $row["family_size"]. ", phone_no: " . $row["phone_no"]."<br>";
  echo '<tr>
    <td><a href="/search_customers_result.php?card_number='. $card_number .'" style="color: #33A1FD;">'. $card_number .'</a></td>
    <td>'.$row["first_name"].'</td>
    <td>'.$row["last_name"].'</td>
    <td>'.$row["total_points"].'</td>
    <td>'.$row["street"].'</td>
    <td>'.$row["number"].'</td>
    <td>'.$row["city"].'</td>
    <td>'.$row["postal_code"].'</td>
    <td>'.$row["birth_year"].'</td>
    <td>'.$row["sex"].'</td>
    <td>'.$row["SSN"].'</td>
    <td>'.$row["family_size"].'</td>
    <td>'.$row["phone_no"].'</td>
  </tr>';
  }
  echo "</table>";
} else{
  echo "<p>There are no customers</p>";
}


?>

<?php
include "footer.html";
?>