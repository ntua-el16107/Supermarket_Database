<?php
include "header.html";

include "connectionphp.php";

$sql = "SELECT pr1.product_name as prod1, pr2.product_name as prod2, COUNT(*) pairs FROM product as pr1, product as pr2, consists_of AS c1
    JOIN consists_of AS c2 ON c1.time = c2.time and c1.date = c2.date AND c1.Barcode < c2.Barcode
	WHERE pr1.Barcode = c1.Barcode AND pr2.Barcode = c2.Barcode GROUP BY c1.Barcode, c2.Barcode ORDER BY pairs DESC";

$result = $conn->query($sql);
echo "<h3>The most popular pairs of products are:</h3>";
if($result->num_rows > 0){
?>

<table style="width:60%">
  <tr>
    <th>Product 1</th>
    <th>Product 2</th>
  </tr>

<?php

  while($row = $result->fetch_assoc()){

  echo '<tr>
    <td>'.$row["prod1"].'</td>
    <td>'.$row["prod2"].'</td>
  </tr>';
  }
  echo "</table>";
  echo "<br>";
} else{
  echo "<p>Has bought no products yet<br><br></p>";
}


$sql = "SELECT DISTINCT B.category_name, etiketes*100/ COUNT(B.category_name) over (partition by B.category_name) as pososto_etiketwn FROM 
(SELECT A.category_name, sum(A.tag) over (partition by A.category_name) as etiketes FROM 
(SELECT category_name,product.barcode, store_tag='y' as tag FROM consists_of,product WHERE product.barcode = consists_of.barcode) AS A) AS B";

$result = $conn->query($sql);
echo "<h3>The percentages of the tags are:</h3>";
if($result->num_rows > 0){
?>

<table style="width:60%">
  <tr>
    <th>Category</th>
    <th>Percentage (%)</th>
  </tr>

<?php

  while($row = $result->fetch_assoc()){

  echo '<tr>
    <td>'.$row["category_name"].'</td>
    <td>'.$row["pososto_etiketwn"].'</td>
  </tr>';
  }
  echo "</table>";
  echo "<br>";
} else{
  echo "<p>Has bought no products yet<br><br></p>";
}


$sql = "SELECT DISTINCT HOUR(`transaction`.time) as timee, sum(total_cost) over (partition by HOUR(`transaction`.time)) as pipis FROM `transaction` ORDER BY pipis DESC";

$result = $conn->query($sql);
echo "<h3>The hours in which the most money is spent:</h3>";
if($result->num_rows > 0){
?>

<table style="width:30%">
  <tr>
    <th>Time</th>
  </tr>

<?php

  while($row = $result->fetch_assoc()){
	$str = preg_replace('/\D/', '', $row["timee"]);
	$x = $str + 1;
	echo "<tr>";
  	echo "<td>".$row["timee"].":00 - ". $x .":00"."</td>";
  	echo "</tr>";
  }
  echo "</table>";
  echo "<br>";
} else{
  echo "<p>Has bought no products yet<br><br></p>";
}

$sql = "SELECT B.H as timeee, SUM(CASE WHEN B.age <31 THEN 1 ELSE 0 END)*100.0/count(B.age) as age1,SUM(CASE WHEN B.age>30 and B.age <61 THEN 1 ELSE 0 END)*100.0/count(B.age) as age2,SUM(CASE WHEN B.age>60 THEN 1 ELSE 0 END)*100.0/count(B.age) as age3 FROM 
(SELECT A.H, year(current_date)-customer.birth_year as age FROM customer,
(SELECT HOUR(transaction.time) as H, transaction.card_number FROM transaction) AS A WHERE A.card_number = customer.card_number) AS B GROUP BY B.H order by B.H";

$result = $conn->query($sql);
echo "<h3>Percentages of age groups:</h3>";
if($result->num_rows > 0){
?>

<table style="width:60%">
  <tr>
    <th>Time</th>
    <th>Percentage (%) for age <= 30</th>
    <th>Percentage (%) for age > 30 and age <=60</th>
    <th>Percentage (%) for age > 60</th>
  </tr>

<?php

  while($row = $result->fetch_assoc()){
	$strr = preg_replace('/\D/', '', $row["timeee"]);
	$y = $strr + 1;
	echo "<tr>";
  	echo "<td>".$row["timeee"].":00 - ". $y .":00"."</td>";
  	echo "<td>".$row["age1"]."</td>";
  	echo "<td>".$row["age2"]."</td>";
  	echo "<td>".$row["age3"]."</td>";
  	echo "</tr>";
  }
  echo "</table>";
  echo "<br>";
} else{
  echo "<p>Has bought no products yet<br><br></p>";
}

?>