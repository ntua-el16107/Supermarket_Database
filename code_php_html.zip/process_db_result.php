<?php

include "connectionphp.php";
include "header.html";
//include "process_db";
$entityfromform = $_GET["entity"];
$processtypefromform = $_GET["processtype"];

//customers
if ($entityfromform == 'customer' && $processtypefromform == 'Insert'){
$cardnumberfromform = $_GET["card_number"];
$totalpointsfromform = $_GET["total_points"];
$cityfromform = $_GET["city"];
$numberfromform = $_GET["number"];
$streetfromform = $_GET["street"];
$postalcodefromform = $_GET["postal_code"];
$firstnamefromform = $_GET["first_name"];
$lastnamefromform = $_GET["last_name"];
$SSNfromform = $_GET["SSN"];
$birthyearfromform = $_GET["birth_year"];
$sexfromform = $_GET["sex"];
$familysizefromform = $_GET["family_size"];
$phonenofromform = $_GET["phone_number"];
$sql = "INSERT INTO customer (card_number, total_points, city, number, street, postal_code, first_name, last_name, SSN, birth_year, sex, family_size, phone_no) VALUES
('$cardnumberfromform', $totalpointsfromform, '$cityfromform' , '$numberfromform', '$streetfromform', '$postalcodefromform', '$firstnamefromform', '$lastnamefromform', '$SSNfromform', $birthyearfromform ,'$sexfromform' , $familysizefromform, $phonenofromform)";
	if ($conn->query($sql) === TRUE) {
	  echo "<p>New record created successfully</p>";
	} else {
	  echo "<p>Error: " . $sql . "<br>" . $conn->error ."</p>";
	}
}
else if ($entityfromform == 'customer' && $processtypefromform == 'Delete'){
$cardnumberfromform = $_GET["card_number"];
$sql = "DELETE FROM customer WHERE card_number = '$cardnumberfromform'";
	if ($conn->query($sql) === TRUE) {
	  echo "<p>Record deleted successfully</p>";
	} else {
	  echo "Error deleting record: " . $conn->error ."</p>";
	}
}
else if ($entityfromform == 'customer' && $processtypefromform == 'Update'){
$cardnumberfromform = $_GET["card_number"];
$totalpointsfromform = $_GET["total_points"];
$cityfromform = $_GET["city"];
$numberfromform = $_GET["number"];
$streetfromform = $_GET["street"];
$postalcodefromform = $_GET["postal_code"];
$firstnamefromform = $_GET["first_name"];
$lastnamefromform = $_GET["last_name"];
$SSNfromform = $_GET["SSN"];
$birthyearfromform = $_GET["birth_year"];
$sexfromform = $_GET["sex"];
$familysizefromform = $_GET["family_size"];
$phonenofromform = $_GET["phone_no"];
$sql = "UPDATE customer SET card_number = '$cardnumberfromform', total_points = $totalpointsfromform, city = '$cityfromform', number = '$numberfromform',
 street = '$streetfromform', postal_code = '$postalcodefromform', first_name = '$firstnamefromform', last_name = '$lastnamefromform', SSN = '$SSNfromform' ,
 birth_year = $birthyearfromform, sex = '$sexfromform', family_size = '$familysizefromform', phone_no = $phonenofromform
WHERE card_number = '$cardnumberfromform'";
	if ($conn->query($sql) === TRUE) {
	  echo "<p>Record updated successfully</p>";
	} else {
	  echo "<p>Error updating record: " . $conn->error ."</p>";
	}
}

//stores
else if ($entityfromform == 'store' && $processtypefromform == 'Insert'){
$storeidfromform = $_GET["store_id"];
$squaremetersfromform = $_GET["square_meters"];
$opensfromform = $_GET["opens"];
$closesfromform = $_GET["closes"];
$cityfromform = $_GET["city"];
$streetfromform = $_GET["street"];
$numberfromform = $_GET["number"];
$postalcodefromform = $_GET["postal_code"];
$sql = "INSERT INTO store (store_id, square_meters, opens, closes, city, street, number, postal_code) VALUES
('$storeidfromform' , '$squaremetersfromform', '$opensfromform', '$closesfromform' , '$cityfromform', '$streetfromform', '$numberfromform',  '$postalcodefromform' )";
	if ($conn->query($sql) === TRUE) {
	  echo "<p>New record created successfully</p>";
	} else {
	  echo "<p>Error: " . $sql . "<br>" . $conn->error . "</p>";
	}
}
else if ($entityfromform == 'store' && $processtypefromform == 'Delete'){
$storeidfromform = $_GET["store_id"];
$sql = "DELETE FROM store WHERE store_id = '$storeidfromform'";
	if ($conn->query($sql) === TRUE) {
	  echo "<p>Record deleted successfully</p>";
	} else {
	  echo "<p>Error deleting record: " . $conn->error. "</p>";
	}
}
else if ($entityfromform == 'store' && $processtypefromform == 'Update'){
$storeidfromform = $_GET["store_id"];
$squaremetersfromform = $_GET["square_meters"];
$opensfromform = $_GET["opens"];
$closesfromform = $_GET["closes"];
$cityfromform = $_GET["city"];
$streetfromform = $_GET["street"];
$numberfromform = $_GET["number"];
$postalcodefromform = $_GET["postal_code"];
$sql = "UPDATE store SET store_id = $storeidfromform, square_meters = '$squaremetersfromform', opens = '$opensfromform', closes = '$closesfromform',
city = '$cityfromform', street = '$streetfromform', number = '$numberfromform', postal_code = '$postalcodefromform'
 WHERE store_id = '$storeidfromform'";
	if ($conn->query($sql) === TRUE) {
		  echo "<p>Record updated successfully</p>";
		} else {
		  echo "<p>Error updating record: " . $conn->error . "</p>";
		}
}

//products
else if ($entityfromform == 'product' && $processtypefromform == 'Insert'){
$barcodefromform = $_GET["barcode"];
$productnamefromform = $_GET["product_name"];
$storetagfromform = $_GET["store_tag"];
$categorynamefromform = $_GET["category_name"];
$sql = "INSERT INTO product (barcode, product_name, store_tag, category_name) VALUES
('$barcodefromform' , '$productnamefromform', '$storetagfromform', '$categorynamefromform' )";
	if ($conn->query($sql) === TRUE) {
	  echo "<p>New record created successfully</p>";
	} else {
	  echo "<p>Error: " . $sql . "<br>" . $conn->error ."</p>";
	}
}	
else if ($entityfromform == 'product' && $processtypefromform == 'Delete'){
$barcodefromform = $_GET["barcode"];
$sql = "DELETE FROM product WHERE barcode = '$barcodefromform'";
	if ($conn->query($sql) === TRUE) {
	  echo "<p>Record deleted successfully</p>";
	} else {
	  echo "<p>Error deleting record: " . $conn->error . "</p>";
	}
	
}

else if ($entityfromform == 'product' && $processtypefromform == 'Update'){
$barcodefromform = $_GET["barcode"];
$productnamefromform = $_GET["product_name"];
$storetagfromform = $_GET["store_tag"];
$categorynamefromform = $_GET["category_name"];
$sql = "UPDATE product SET barcode = '$barcodefromform', product_name = '$productnamefromform', store_tag = '$storetagfromform', category_name = '$categorynamefromform'
WHERE barcode = '$barcodefromform'";
	if ($conn->query($sql) === TRUE) {
	  echo "<p>Record updated successfully</p>";
	} else {
	  echo "<p>Error updating record: " . $conn->error . "</p>";
	}
}
?>

<?php
include "footer.html";
?>