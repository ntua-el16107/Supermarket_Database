<?php

include "connectionphp.php";
include "header.html";

$storefromform = $_GET["store"];
$datefromform = $_GET["date"];
$productunitsfromform = $_GET["product_units"];
$productunitsminfromform = $_GET["product_units_min"];
$productunitsmaxfromform = $_GET["product_units_max"];
$totalcostminfromform = $_GET["total_cost_min"];
$totalcostmaxfromform = $_GET["total_cost_max"];
$paymentmethodfromform = $_GET["payment_method"];
$productcategoryfromform = $_GET["product_category"];

$flag = 0;

echo "<h2> Show requested transactions </h2>";

$where = "WHERE store_id = '$storefromform'";
if(!empty($paymentmethodfromform)){
	$where .= " AND payment_method = '$paymentmethodfromform'";
}
if(!empty($datefromform)){
	$where .= " AND date = '$datefromform'";
	//echo $datefromform;
}
if(!empty($totalcostminfromform)){
	$where .= " AND total_cost >= $totalcostminfromform";
}
if(!empty($totalcostmaxfromform)){
	$where .= " AND total_cost <= $totalcostmaxfromform";
}
if(!empty($productunitsfromform)){
		$where .= " AND (card_number, time, date, $productunitsfromform) in (SELECT card_number, time, date, sum(quantity) FROM consists_of GROUP BY card_number, time, date)";
}
if(!empty($productunitsminfromform)){
		$where .= " AND (card_number, time, date) in (SELECT card_number, time, date FROM consists_of GROUP BY card_number, time, date HAVING sum(quantity) >= $productunitsminfromform)";
}
if(!empty($productunitsmaxfromform)){
		$where .= " AND (card_number, time, date) in (SELECT card_number, time, date FROM consists_of GROUP BY card_number, time, date HAVING sum(quantity) <= $productunitsmaxfromform)";
}
if(!empty($productcategoryfromform)){
	$compl_sql = "SELECT * FROM has_categories WHERE store_id = '$storefromform' AND name = '$productcategoryfromform'";
	$compl_result = $conn->query($compl_sql);
	if($compl_result->num_rows == 0){
		$flag = 1;
	}

	$sql = "SELECT distinct transaction.card_number, transaction.time, transaction.date, transaction.payment_method, transaction.total_cost, transaction.store_id FROM transaction, consists_of, product $where AND transaction.card_number = consists_of.card_number AND transaction.date = consists_of.date AND transaction.time = consists_of.time AND consists_of.barcode = product.barcode AND product.category_name = '$productcategoryfromform' ";
}
else{
	$sql = "SELECT * FROM transaction $where";
}

$result = $conn->query($sql);
if($result->num_rows > 0){
?>

<table style="width:60%">
  <tr>
    <th>Card number</th>
    <th>Date</th> 
    <th>Time</th>
    <th>Payment method</th>
    <th>Total cost</th>
    <th>Store ID</th>
  </tr>

<?php
//if($result->num_rows > 0){
	while($row = $result->fetch_assoc()){
		//echo "card_number: " . $row["card_number"].  ", time: " . $row["time"]. ", date: " . $row["date"]. ", payment_method: " . $row["payment_method"]. ", total_cost: " . $row["total_cost"]. ", store_id: " . $row["store_id"]. "<br>";
		echo '<tr>
    <td>'.$row["card_number"].'</td>
    <td>'.$row["date"].'</td>
    <td>'.$row["time"].'</td>
    <td>'.$row["payment_method"].'</td>
    <td>'.$row["total_cost"].'</td>
    <td>'.$row["store_id"].'</td>
  </tr>';
	}
	echo "</table>";
} else{
	if($flag == 1){
		echo "<p>Store ". $storefromform ." doesn't have category: ". $productcategoryfromform .".</p>";
	} else{
		echo "<p>0 results</p>";
	}
}

?>

<?php
include "footer.html";
?>