<?php
include "header.html";

include "connectionphp.php";

$sql = "SELECT * FROM product_category";
$result = $conn->query($sql);
?>

<h2>View transactions per store and/or per product category</h2>

<form action="view_sales.php">
  <label for="store">Select a store:</label><br>
  <input type="text" name="store"><br>
  <label for="product_category">Select a product category:</label><br>
  <select id="product_category" name="product_category">
    <option></option>

<?php
  while($row = $result->fetch_assoc()){
    echo '<option value="'. $row["name"] .'">'. $row["name"] .'</option>';
  }  
?>
  </select><br>
  <input type="submit" value="Submit">
</form>

<?php
include "footer.html";
?>