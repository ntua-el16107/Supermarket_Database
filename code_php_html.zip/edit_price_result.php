<?php
include "header.html";

include "connectionphp.php";

$option = explode(",",$_POST["radio_name"]);

$barcodefromform = $option[0];
$storefromform = $option[1];


echo "<h2>Edit price for product with barcode: ". $barcodefromform ."</h2>";
?>


<form action="edit_price_result2.php" method="post">
  <label for="current_price">Edit price:(*)</label><br>
  <input required type="float"  placeholder="Enter Price"  name="current_price" min="0"><br>
	<input type='hidden' name='kati1' value="<?php echo $barcodefromform; ?>" >
         <input type='hidden' name='kati2' value="<?php echo $storefromform; ?>" >

 <input type="submit" value="Submit">
</form>

<?php
include "footer.html";
?>
