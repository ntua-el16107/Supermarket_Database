<?php

include "connectionphp.php";

include "header.html";
?>

<h3>Welcome!</h3>

<?php
include "footer.html";

$conn->close();
?>
