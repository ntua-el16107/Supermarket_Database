<?php
include "header.html";

include "connectionphp.php";

$sql = "SELECT * FROM transaction";

$result = $conn->query($sql);

while($row = $result->fetch_assoc()){
	$card_number1=$row["card_number"];
	$time1=$row["time"];
	$date1=$row["date"];
	$store_id1=$row["store_id"];
	$sql2 = "SELECT SUM(has_products.current_price * consists_of.quantity) AS tootal FROM consists_of, has_products WHERE consists_of.card_number = '$card_number1' AND consists_of.time = '$time1' AND consists_of.date = '$date1' AND consists_of.barcode = has_products.barcode AND has_products.store_id = '$store_id1'";
	$result2 = $conn->query($sql2);
	$row2 = $result2->fetch_assoc();
	$total = $row2["tootal"];

	$sql1 = "UPDATE transaction SET total_cost = $total WHERE card_number = '$card_number1' AND time = '$time1' AND date = '$date1'";
	$result1 = $conn->query($sql1);
}

include "footer.html";
?>

