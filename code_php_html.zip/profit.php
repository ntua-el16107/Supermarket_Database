<?php
include "header.html";

include "connectionphp.php";

echo "<h3>The most profitable stores are:</h3>";

$sql = "SELECT store.store_id as mystore, sum(transaction.total_cost) as tootal FROM store, transaction WHERE store.store_id = transaction.store_id group by mystore order by tootal DESC";

$result = $conn->query($sql);

if($result->num_rows > 0){
?>

<table style="width:60%">
  <tr>
    <th>Store ID</th>
    <th>Total profit</th>
  </tr>

<?php

  while($row = $result->fetch_assoc()){

  echo '<tr>
    <td>'.$row["mystore"].'</td>
    <td>'.$row["tootal"].'</td>
  </tr>';
  }
  echo "</table>";
  echo "<br>";
} else{
  echo "<p>Has bought no transactions yet<br><br></p>";
}

?>