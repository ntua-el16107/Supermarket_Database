<?php
include "header.html";
include "connectionphp.php";

$storefromform = $_POST["store"];

echo "<h2>Products in store with id: ".$storefromform ."</h2>";

$sql = "SELECT product.barcode,product.product_name,has_products.current_price FROM product, has_products WHERE has_products.store_id='$storefromform' AND product.barcode=has_products.barcode";

$result = $conn->query($sql);
if($result->num_rows > 0){

?>

<table style="width:60%">
  <tr>
    <th>Barcode</th>
    <th>Name</th> 
    <th>Price</th>
  </tr>
<form action="edit_price_result.php" method="post">
<?php

while($row = $result->fetch_assoc()){

    echo "<tr><td><input type='radio' name='radio_name' value=' $row[barcode], $storefromform '>" . $row["barcode"]."</td><td>" .$row["product_name"]."</td><td>".$row["current_price"]."</td><tr>";
  
  }
  echo "</table>";
} else{
  echo "<p>There are no products</p>";
}


?>

<button type="submit">Edit Price</button>
<button type="submit" formaction="/view_history.php">View History</button>

</form>
<?php
include "footer.html";
?>