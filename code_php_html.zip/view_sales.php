<?php
include "header.html";

include "connectionphp.php";

$store_idfromform = $_GET["store"];
$category_namefromform = $_GET["product_category"];

echo "<h2>The required transactions are:</h2>";

$sql = "SELECT date, time, total_cost, first_name, last_name, payment_method, category_name, store_id FROM sales_view";


if (!empty($store_idfromform)) {
    $sql .= " WHERE sales_view.store_id = '$store_idfromform'";
}

if (!empty($category_namefromform)) {
    $sql .= " AND sales_view.category_name ='$category_namefromform'";
}

$result = $conn->query($sql);
if($result->num_rows > 0){
?>

<table style="width:80%">
  <tr>
    <th>Transaction date</th>
    <th>Transaction time</th> 
    <th>Store ID</th>   
    <th>Total cost</th>
    <th>First name</th>
    <th>Last name</th>
    <th>Payment method</th>
    <th>Category name</th>
  </tr>

<?php
  while($row = $result->fetch_assoc()){
    echo '<tr>
    <td>'.$row["date"].'</td>
    <td>'.$row["time"].'</td>
    <td>'.$row["store_id"].'</td>
    <td>'.$row["total_cost"].'</td>
    <td>'.$row["first_name"].'</td>
    <td>'.$row["last_name"].'</td>
    <td>'.$row["payment_method"].'</td>
    <td>'.$row["category_name"].'</td>
  </tr>';
  }
  echo "</table>";
} else{
    echo "<p>0 results</p>";

}


include "footer.html";
?>
