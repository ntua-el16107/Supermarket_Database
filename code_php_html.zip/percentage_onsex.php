<?php
include "header.html";

include "connectionphp.php";

$sql = "SELECT first.barcode, product.product_name, (first.trans_bywomen * 100.0 / first.total_trans) AS percentage1, (100.0 - (first.trans_bywomen * 100.0 / first.total_trans)) AS percentage2 FROM (SELECT consists_of.barcode, SUM(CASE WHEN customer.sex='f' THEN consists_of.quantity ELSE 0 END), SUM(consists_of.quantity) FROM consists_of, customer WHERE customer.card_number = consists_of.card_number GROUP BY barcode) AS first(barcode, trans_bywomen, total_trans), product WHERE product.barcode = first.barcode";


$result = $conn->query($sql);
echo "<h3>The percentage of sales for each product based on sex: </h3>";
if($result->num_rows > 0){
?>

<table style="width:60%">
  <tr>
    <th>Barcode</th>
    <th>Product name</th> 
    <th>Bought by women(%)</th>
    <th>Bought by men(%)</th>
  </tr>

<?php
  while($row = $result->fetch_assoc()){
  echo '<tr>
    <td>'.$row["barcode"].'</td>
    <td>'.$row["product_name"].'</td>
    <td>'.$row["percentage1"].'</td>
    <td>'.$row["percentage2"].'</td>
  </tr>';
  }
  echo "</table>";
  echo "<br>";
} else{
  echo "<p>There are no sales.</p><br><br>";
}

include "footer.html";
?>