<?php
include "header.html";
?>

<h2>Select a store in order to see its products and edit their prices</h2>

<form action="edit_price.php" method="post" >
  <label for="store">Select a store:(*)</label><br>
  <input required type="text" name="store"><br><br>
  <input type="submit" value="Submit">
</form>

<?php
include "footer.html";
?>
