<?php
include "header.html";

include "connectionphp.php";


$option = explode(",",$_POST["radio_name"]);

$barcodefromform = $option[0];
$storefromform = $option[1];
$barcodefromform = str_replace(' ', '', $barcodefromform);
$storefromform = str_replace(' ', '', $storefromform);

$sql1="select * from old_price where barcode = '".$barcodefromform."' AND store_id ='". $storefromform."' ";


$result1= $conn->query($sql1);
if($result1->num_rows > 0){
  echo "<h2>History of old prices for product with barcode: ". $barcodefromform ." in store with id: ".$storefromform. "</h2>";
?>

<table style="width:60%">
  <tr>
    <th>Barcode</th>
    <th>Price</th>
    <th>Start Date</th>    
    <th>End Date</th>
  </tr>

<?php

  while($row = $result1->fetch_assoc()){

  echo '<tr>
    <td>'.$row["barcode"].'</td>
    <td>'.$row["price"].'</td>
    <td>'.$row["start_date"].'</td>
  <td>'  .$row["end_date"]. '</td></tr>' ;
  }
  echo "</table>";
  echo "<br>";
} else{
  echo "<p>No History</p><br><br>";
}

?>