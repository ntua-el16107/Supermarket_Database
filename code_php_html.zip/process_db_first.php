<?php
include "header.html";

?>
<h2>PROCESS DATABASE</h2><br><br>
<form action="process_db.php" name="processdb">
Entity:       <select id="entity" name="entity">
				  <option value='customer'>customer</option>
				  <option value='store'>store</option>
				  <option value='product'>product</option>
			  </select><br>
Type of proccess:       <select id="processtype" name="processtype">
							<option value='Insert'>Insert</option>
							<option value='Delete'>Delete</option>
							<option value='Update'>Update</option>
						</select><br>

<input type="submit" value="Submit">
<input type="reset" value="Reset">
</form>

<?php
include "footer.html";
?>
