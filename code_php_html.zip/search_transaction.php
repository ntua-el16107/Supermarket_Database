<?php
include "header.html";

include "connectionphp.php";

$sql = "SELECT * FROM product_category";
$result = $conn->query($sql);
?>

<h2>Search for transactions in a store based on several criteria</h2>

<form action="search_transaction_result.php">
  <label for="store">Select a store:(*)</label><br>
  <input required type="text" name="store"><br><br>
  <p>Limit the results filling in any of the following filters you want:</p><br>
  <label for="date">Select a date:</label><br>
  <input type="date" name="date"><br>
  <label for="product_units_min">Select range of product units:</label><br>
  <input type="number" name="product_units_min" min="1">
  <input type="number" name="product_units_max" min="1"><br>
  <label for="product_units">Or a specific number of product units:</label><br>
  <input type="number" name="product_units" min="1"><br>
  <label for="total_cost">Select range of total cost:</label><br>
  <input type="number" name="total_cost_min" step="0.01">
  <input type="number" name="total_cost_max" step="0.01"><br>
  <label for="payment_method">Select the payment method:</label><br>
  <select id="payment_method" name="payment_method">
    <option></option>
    <option value="cash">Cash</option>
    <option value="credit card">Credit Card</option>
  </select><br>
  <label for="product_category">Select a product category:</label><br>
  <select id="product_category" name="product_category">
    <option></option>

<?php
  while($row = $result->fetch_assoc()){
    echo '<option value="'. $row["name"] .'">'. $row["name"] .'</option>';
  }  
?>
  </select><br>
  <input type="submit" value="Submit">
</form>

<?php
include "footer.html";
//    <option disabled selected value> </option>
?>