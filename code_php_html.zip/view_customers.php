<?php
include "header.html";

include "connectionphp.php";

echo "<h2>The customers are:</h2>";

$sql = "SELECT card_number, first_name, last_name, total_points, birth_year, city, street, number, postal_code, family_size, SSN, sex, phone_no FROM customer_view";


$result = $conn->query($sql);
if($result->num_rows > 0){
?>

<table style="width:100%">
  <tr>
    <th>Card number</th>
    <th>First name</th> 
    <th>Last name</th>   
    <th>Total points</th>
    <th>Birth year</th>
    <th>City</th>
    <th>Street</th>
    <th>Number</th>
    <th>Postal code</th>
    <th>Family size</th>
    <th>SSN</th>
    <th>Sex</th>
    <th>Phone number</th>
  </tr>

<?php
  while($row = $result->fetch_assoc()){
    echo '<tr>
    <td>'.$row["card_number"].'</td>
    <td>'.$row["first_name"].'</td>
    <td>'.$row["last_name"].'</td>
    <td>'.$row["total_points"].'</td>
    <td>'.$row["birth_year"].'</td>
    <td>'.$row["city"].'</td>
    <td>'.$row["street"].'</td>
    <td>'.$row["number"].'</td>
    <td>'.$row["postal_code"].'</td>
    <td>'.$row["family_size"].'</td>
    <td>'.$row["SSN"].'</td>
    <td>'.$row["sex"].'</td>
    <td>'.$row["phone_no"].'</td>
  </tr>';
  }
  echo "</table>";
} else{
    echo "<p>0 results</p>";

}


include "footer.html";
?>
