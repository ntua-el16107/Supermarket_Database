<?php
include "header.html";
include "connectionphp.php";

$entityfromform = $_GET["entity"];
$processtypefromform = $_GET["processtype"];

if ($entityfromform == 'customer' && $processtypefromform == 'Insert'){ 
?>
<h2>Add a new customer</h2><br>

<form action="process_db_result.php" name="insert_customer">
<input type="hidden" name="entity" value="customer">
<input type="hidden" name="processtype" value="Insert">
Card Number:(*) <input required type="text" name="card_number" placeholder="e.g. ABGS5467QR"><br><br>
First Name: <input type="text" name="first_name" placeholder="e.g. NIKOLETA"><br>
Last Name: <input type="text" name="last_name" placeholder="e.g. NIKOLAOU"><br>
Total Points: <input type="number" name="total_points" placeholder=0><br>
Street: <input type="text" name="street" placeholder="e.g. VALAORITOY"><br>
Number: <input type="text" name="number" placeholder="e.g. 156"><br>
City: <input type="text" name="city" placeholder="e.g. ATHENS"><br>
Postal Code: <input type="text" name="postal_code" placeholder="e.g. 15122"><br>
Birth Year: <input type="number" name="birth_year" placeholder=0><br>
Sex: <br>
	<input type="radio" id="male" name="sex" value="M">
	<label for="male">Male</label><br>
    <input type="radio" id="female" name="sex" value="F">
    <label for="female">Female</label><br>
    <input type="radio" id="other" name="sex" value="O">
    <label for="other">Other</label><br>
SSN: <input type="text" name="SSN" placeholder="e.g. 345186372"><br>
Family Size: <input type="number" name="family_size" placeholder=0><br>
Phone Number: <input type="text" name="phone_number" placeholder="e.g. 6973552417"><br>
<input type="submit" value="Insert" name="customersubmitForm" >
<input type="reset" value="Reset">	
</form>
<?php
}
else if ($entityfromform == 'customer' && $processtypefromform == 'Delete'){
?>
	<h2>Delete an old customer</h2><br>

<form action="process_db_result.php" name="delete_customer">
<input type="hidden" name="entity" value="customer">
<input type="hidden" name="processtype" value="Delete">
Card Number:(*) <input required type="text" name="card_number" placeholder="e.g. ABGS5467QR"><br>
<input type="submit" value="Delete" name="customersubmitForm">
<input type="reset" value="Reset">
</form>

<?php
}
else if ($entityfromform == 'customer' && $processtypefromform == 'Update'){
?>
	<h2>Update customer</h2><br>

<form action="process_db_result.php" name="update_customer">
<input type="hidden" name="entity" value="customer">
<input type="hidden" name="processtype" value="Update">
Card Number:(*) <input required type="text" name="card_number" placeholder="e.g. ABGS5467QR"><br><br>
First Name: <input type="text" name="first_name" placeholder="e.g. NIKOLETA"><br>
Last Name: <input type="text" name="last_name" placeholder="e.g. NIKOLAOU"><br>
Total Points: <input type="number" name="total_points" placeholder=0><br>
Street: <input type="text" name="street" placeholder="e.g. VALAORITOY"><br>
Number: <input type="text" name="number" placeholder="e.g. 156"><br>
City: <input type="text" name="city" placeholder="e.g. ATHENS"><br>
Postal Code: <input type="text" name="postal_code" placeholder="e.g. 15122"><br>
Birth Year: <input type="number" name="birth_year" placeholder=0><br>
Sex: <br>
	<input type="radio" id="male" name="sex" value="M">
	<label for="male">Male</label><br>
    <input type="radio" id="female" name="sex" value="F">
    <label for="female">Female</label><br>
    <input type="radio" id="other" name="sex" value="O">
    <label for="other">Other</label><br>
SSN: <input type="text" name="SSN" placeholder="e.g. 345186372"><br>
Family Size: <input type="number" name="family_size" placeholder=0><br>
Phone Number: <input type="text" name="phone_number" placeholder="e.g. 6973552417"><br>
<input type="submit" value="Update" name="customersubmitForm" >
<input type="reset" value="Reset">
</form><br><br>
<?php
}
else if ($entityfromform == 'store' && $processtypefromform == 'Insert'){
?>
	<h2>Insert a store</h2><br>

<form action="process_db_result.php" name="insert_store">
<input type="hidden" name="entity" value="store">
<input type="hidden" name="processtype" value="Insert">
Store Id:(*) <input required type="text" name="store_id" placeholder="e.g. ATH01"><br>
Square Meters: <input type="text" name="square_meters" placeholder="e.g. 250"><br>
Opens: <input type="text" name="opens" placeholder="e.g. 08:00"><br>
Closes: <input type="text" name="closes" placeholder="e.g. 21:00"><br>
Street: <input type="text" name="street" placeholder="e.g. VALAORITOY"><br>
Number: <input type="text" name="number" placeholder="e.g. 156"><br>
City: <input type="text" name="city" placeholder="e.g. ATHENS"><br>
Postal Code: <input type="text" name="postal_code" placeholder="e.g. 15122"><br>
<input type="submit" value="Insert" name="storesubmitForm" >
<input type="reset" value="Reset">
</form>
<?php	
}
else if ($entityfromform == 'store' && $processtypefromform == 'Delete'){
?>
	<h2>Delete an old store</h2><br>

<form action="process_db_result.php" name="delete_store">
<input type="hidden" name="entity" value="store">
<input type="hidden" name="processtype" value="Delete">
Store Id:(*) <input required type="text" name="store_id" placeholder="e.g. ATH01"><br>
<input type="submit" value="Delete" name="storesubmitForm" >
<input type="reset" value="Reset">
</form>

<?php
}
else if ($entityfromform == 'store' && $processtypefromform == 'Update'){
?>
	<h2>Update an old store</h2><br>

<form action="process_db_result.php" name="update_store">
<input type="hidden" name="entity" value="store">
<input type="hidden" name="processtype" value="Update">
Store Id:(*) <input required type="text" name="store_id" placeholder="e.g. ATH01"><br>
Square Meters: <input type="text" name="square_meters" placeholder="e.g. 250"><br>
Opens: <input type="text" name="opens" placeholder="e.g. 08:00"><br>
Closes: <input type="text" name="closes" placeholder="e.g. 21:00"><br>
Street: <input type="text" name="street" placeholder="e.g. VALAORITOY"><br>
Number: <input type="text" name="number" placeholder="e.g. 156"><br>
City: <input type="text" name="city" placeholder="e.g. ATHENS"><br>
Postal Code: <input type="text" name="postal_code" placeholder="e.g. 15122"><br>
<input type="submit" value="Update" name="storesubmitForm" >
<input type="reset" value="Reset">
</form><br><br>

<?php	
}
else if ($entityfromform == 'product' && $processtypefromform == 'Insert'){
?>
	<h2>Add a new product</h2><br>

<form action="process_db_result.php" name="insert_product">
<input type="hidden" name="entity" value="product">
<input type="hidden" name="processtype" value="Insert">
Barcode:(*) <input required type="text" name="barcode" placeholder="e.g. 156738920174567"><br><br>
Product Name: <input type="text" name="product_name" placeholder="e.g. orange"><br>
Category Name: <select id="category_name" name="category_name">
				  <option value='Frozen Food'>Frozen Food</option>
				  <option value='Fresh Food'>Fresh Food</option>
				  <option value='Personal Care'>Personal Care</option>
				  <option value='Spirits'>Spirits</option>
				  <option value='Pet'>Pet</option>
				  <option value='House'>House</option>
              </select><br>
Store Tag: <br>
			<input type="radio" id="yes" name="store_tag" value="y">
			<label for="yes">YES</label><br>
			<input type="radio" id="no" name="store_tag" value="n">
			<label for="no">NO</label><br>
<input type="submit" value="Insert" name="productsubmitForm" >
<input type="reset" value="Reset">
</form>

<?php	
}
else if ($entityfromform == 'product' && $processtypefromform == 'Delete'){
?>
	<h2>Delete an old product</h2><br>

<form action="process_db_result.php" name="delete_product">
<input type="hidden" name="entity" value="product">
<input type="hidden" name="processtype" value="Delete">
Barcode:(*) <input required type="text" name="barcode" placeholder="e.g. 164453772891234"><br><br>
<input type="submit" value="Delete" name="productsubmitForm" >
<input type="reset" value="Reset">
</form>

<?php	
}
else if ($entityfromform == 'product' && $processtypefromform == 'Update'){
?>
	<h2>Update an old product</h2><br>
<form action="process_db_result.php" name="update_product">
<input type="hidden" name="entity" value="product">
<input type="hidden" name="processtype" value="Update">
Barcode:(*) <input required type="text" name="barcode" placeholder="e.g. 156738920174567"><br><br>
Product Name: <input type="text" name="product_name" placeholder="e.g. orange"><br>
Category Name: <select id="category_name" name="category_name">
				  <option value='Frozen Food'>Frozen Food</option>
				  <option value='Fresh Food'>Fresh Food</option>
				  <option value='Personal Care'>Personal Care</option>
				  <option value='Spirits'>Spirits</option>
				  <option value='Pet'>Pet</option>
				  <option value='House'>House</option>
              </select><br>
Store Tag: <br>
			<input type="radio" id="yes" name="store_tag" value="y">
			<label for="yes">YES</label><br>
			<input type="radio" id="no" name="store_tag" value="n">
			<label for="no">NO</label><br>
<input type="submit" value="Update" name="productsubmitForm" >
<input type="reset" value="Reset">
</form>
<?php	
}


?>



<?php
include "footer.html";
?>