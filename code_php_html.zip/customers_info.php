<?php
/*
$servername = "localhost";
$username = "root";
$password = "1512";
$dbname = "vaseis";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error){
	die("Connection failed: " . $conn->connect_error);
}
*/
include "connectionphp.php";

//echo "Connected successfully". "<br>";
/*
$sql = "SELECT card_number, first_name, last_name FROM customer";
$result = $conn->query($sql);

if($result->num_rows > 0){
	while($row = $result->fetch_assoc()){
		echo "card_number: " . $row["card_number"]. " - Name: " . $row["first_name"]. " " . $row["last_name"]. "<br>";
	}
} else{
	echo "0 results";
}
*/
?>

<!DOCTYPE html>
<html>
<form action="search_transaction.php">
  <label for="store">Select a store:(*)</label><br>
  <input required type="text" name="store"><br><br>
  <p>Fill in one or more of the following:</p><br>
  <label for="date">Select a date:</label><br>
  <input type="date" name="date"><br>
<!--  <label for="product">Select a product</label> -->
  <label for="product_units">Select the number of product units:</label><br>
<!--  <input type="text" name="product"> -->
  <input type="number" name="product_units" min="1"><br>
  <label for="total_cost">Select the total cost:</label><br>
  <input type="text" name="total_cost"><br>
  <label for="payment_method">Select the payment method:</label><br>
  <input type="text" name="payment_method"><br>
  <label for="product_category">Select a product category:</label><br>
  <input type="text" name="product_category"><br><br>
  <input type="submit" value="Submit">
</form>
</html>


<?php
/*
$sql = "SELECT card_number, time, date, total_cost FROM transaction WHERE payment_method LIKE '%card' AND store_id = store";
$result = $conn->query($sql);

if($result->num_rows > 0){
	while($row = $result->fetch_assoc()){
		echo "card_number: " . $row["card_number"].  ", total_cost: " . $row["total_cost"]. ", time: " . $row["time"]. ", date: " . $row["date"]."<br>";
	}
} else{
	echo "0 results";
}
*/
//include "search_transaction.php";
$conn->close();
?>