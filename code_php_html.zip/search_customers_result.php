<?php
include "header.html";

include "connectionphp.php";

$cardnumberfromform = $_GET["card_number"];
//echo $cardnumberfromform;
echo "<h2>Customer with card number: ". $cardnumberfromform ."</h2>";

$sql = "SELECT * FROM transaction WHERE card_number = '$cardnumberfromform'";  //WHERE card_number = IDK WHAT but the ID I clicked

$result = $conn->query($sql);
echo "<h3>Their transactions are:</h3>";
if($result->num_rows > 0){
?>

<table style="width:60%">
  <tr>
    <th>Card number</th>
    <th>Date</th> 
    <th>Time</th>
    <th>Payment method</th>
    <th>Total cost</th>
    <th>Store ID</th>
  </tr>

<?php
//if($result->num_rows > 0){     
  //echo "<p>The transactions of customer with card number ". $cardnumberfromform ." are:<br><br></p>";
  while($row = $result->fetch_assoc()){
    //echo "card_number: " . $row["card_number"].  ", time: " . $row["time"]. ", date: " . $row["date"]. ", payment_method: " . $row["payment_method"]. ", total_cost: " . $row["total_cost"]. ", store_id: " . $row["store_id"]. "<br>";
  echo '<tr>
    <td>'.$row["card_number"].'</td>
    <td>'.$row["date"].'</td>
    <td>'.$row["time"].'</td>
    <td>'.$row["payment_method"].'</td>
    <td>'.$row["total_cost"].'</td>
    <td>'.$row["store_id"].'</td>
  </tr>';
  }
  echo "</table>";
  echo "<br>";
} else{
  echo "<p>This customer has no transactions</p><br><br>";
}


$sql = "SELECT product.barcode, product.product_name, product.category_name, product.store_tag FROM product, (SELECT barcode, sum(quantity) FROM consists_of WHERE card_number = '$cardnumberfromform' GROUP BY barcode) AS top_barcodes(barcode, sumquantity) WHERE product.barcode = top_barcodes.barcode ORDER BY sumquantity DESC limit 10";

$result = $conn->query($sql);
echo "<h3>The 10 most popular products that this customer buys are:</h3>";
if($result->num_rows > 0){
?>

<table style="width:60%">
  <tr>
    <th>Barcode</th>
    <th>Product name</th> 
    <th>Category</th>
    <th>Store tag</th>
  </tr>

<?php

//if($result->num_rows > 0){    
  //echo "<h3>The 10 most popular products that customer with card number ". $cardnumberfromform ." buys:</h3><br><br>";
  while($row = $result->fetch_assoc()){
  //  echo "barcode: " . $row["barcode"].  ", product_name: " . $row["product_name"]. ", category_name: " . $row["category_name"]. ", store_tag: " . $row["store_tag"]. "<br>";
  echo '<tr>
    <td>'.$row["barcode"].'</td>
    <td>'.$row["product_name"].'</td>
    <td>'.$row["category_name"].'</td>
    <td>'.$row["store_tag"].'</td>
  </tr>';
  }
  echo "</table>";
  echo "<br>";
} else{
  echo "<p>Has bought no products yet<br><br></p>";
}

$sql = "SELECT count(distinct store.store_id) AS result FROM store, transaction WHERE store.store_id = transaction.store_id AND transaction.card_number = '$cardnumberfromform'";

$result = $conn->query($sql);
if($result->num_rows > 0){
  echo "<h3>They visit ";
  $row = $result->fetch_assoc();  
  echo $row["result"]. " stores. These are:</h3>";
}

$sql = "SELECT distinct store.store_id, street, number, city, postal_code, opens, closes, square_meters FROM store, transaction WHERE store.store_id = transaction.store_id AND transaction.card_number = '$cardnumberfromform'";

$result1 = $conn->query($sql);
//echo "<h3>The stores that the customer with card number ". $cardnumberfromform ." visits are:</h3>";
if($result1->num_rows > 0){
  $i = 0;
  $storesfortimes = array();
  $opensfortimes = array();
  $closesfortimes = array();
?>

<table style="width:60%">
  <tr>
    <th>Store ID</th>
    <th>Street</th> 
    <th>Number</th>
    <th>City</th>
    <th>Postal code</th>
    <th>Opens</th> 
    <th>Closes</th>
    <th>Square meters</th>
  </tr>

<?php

//if($result->num_rows > 0){    
  //echo "The stores that the customer with card number ". $cardnumberfromform ." visits are:<br><br>";
  while($row = $result1->fetch_assoc()){
  //  echo "store_id: " . $row["store_id"].  ", street: " . $row["street"]. ", number: " . $row["number"]. ", city: " . $row["city"]. ", postal_code: " . $row["postal_code"]. ", opens: " . $row["opens"]. ", closes: " . $row["closes"]. ", square_meters: " . $row["square_meters"]."<br>";
  $storesfortimes[$i] = $row["store_id"];
  $opensfortimes[$i] = $row["opens"];
  $closesfortimes[$i] = $row["closes"];
  $i = $i + 1;
  echo '<tr>
    <td>'.$row["store_id"].'</td>
    <td>'.$row["street"].'</td>
    <td>'.$row["number"].'</td>
    <td>'.$row["city"].'</td>
    <td>'.$row["postal_code"].'</td>
    <td>'.$row["opens"].'</td>
    <td>'.$row["closes"].'</td>
    <td>'.$row["square_meters"].'</td>
  </tr>';
  }
  echo "</table>";
  echo "<br>";
} else{
  echo "<p>Has visited no stores yet</p>";
}

$sql = "SELECT CONCAT(YEAR(theybought.date), '/', WEEK(theybought.date)) AS week_name, YEAR(theybought.date), WEEK(theybought.date), AVG(theybought.total_cost) AS avg_cost FROM (SELECT * FROM transaction WHERE card_number = '$cardnumberfromform') AS theybought(card_number, time, date, payment_method, total_cost, store_id) GROUP BY week_name ORDER BY YEAR(date) DESC, WEEK(date) DESC";

$result = $conn->query($sql);

if($result->num_rows > 0){
echo "<h3>Average total cost of customer's transactions grouped by week:</h3>"
?>


<table style="width:25%">
  <tr>
    <th>Year/Week</th>
    <th>Average</th> 
  </tr>

<?php

  while($row = $result->fetch_assoc()){
  echo '<tr>
    <td>'.$row["week_name"].'</td>
    <td>'.$row["avg_cost"].'</td>
  </tr>';
  }
  echo "</table>";
  echo "<br>";
} else{
  echo "<p>Has made no transactions</p>";
}

$sql = "SELECT CONCAT(YEAR(theybought.date), '/', MONTH(theybought.date)) AS month_name, YEAR(theybought.date), MONTH(theybought.date), AVG(theybought.total_cost) AS avg_cost FROM (SELECT * FROM transaction WHERE card_number = '$cardnumberfromform') AS theybought(card_number, time, date, payment_method, total_cost, store_id) GROUP BY month_name ORDER BY YEAR(date) DESC, MONTH(date) DESC";

$result = $conn->query($sql);

if($result->num_rows > 0){
echo "<h3>Average total cost of customer's transactions grouped by month:</h3>"
?>


<table style="width:25%">
  <tr>
    <th>Year/Month</th>
    <th>Average</th> 
  </tr>


<?php

  while($row = $result->fetch_assoc()){
  echo '<tr>
    <td>'.$row["month_name"].'</td>
    <td>'.$row["avg_cost"].'</td>
  </tr>';
  }
  echo "</table>";
  echo "<br>";
} else{
  echo "<p>Has made no transactions</p>";
}
//print_r($storesfortimes);
?>
</body>

<?php

if($result1->num_rows > 0){
for($i = 0; $i < $result1->num_rows; $i++){
  $currentstore = $storesfortimes[$i];
  $sql = "SELECT HOUR(theybought.time) AS hour_name, COUNT(*) AS no_of_transactions FROM (SELECT * FROM transaction WHERE card_number = '$cardnumberfromform' AND store_id = '$currentstore') AS theybought(card_number, time, date, payment_method, total_cost, store_id) GROUP BY hour_name ORDER BY hour_name ASC";

  $result = $conn->query($sql);


?>


<?php
//$arr=array_fill(0, max($closesfortimes) - min($opensfortimes) - 1, array());
$hours1 = array_shift(explode(':', max($closesfortimes)));
$hours2 = array_shift(explode(':', min($opensfortimes)));
//echo max($closesfortimes);
//echo " ". min($opensfortimes). '<br>';
$dataPoints[$i] = array_fill(0, $hours1-$hours2-1, 0);

for($j=$hours2; $j<=$hours1; $j++){
  $dataPoints[$i][$j-$hours2] = array("x"=>$j, "y"=>0);
}



while($row = $result->fetch_assoc()){
  //array("x"=> $row["hour_name"], "y"=> $row["no_of_transactions"]);
  $dataPoints[$i][($row["hour_name"] - $hours2)] = array("x"=> $row["hour_name"], "y"=> $row["no_of_transactions"]);
}


}

//print_r($dataPoints);
?>


<?php 
//}
?>


<script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("chartContainer", {
  title: {
    text: "Transactions per hour"
  },
  theme: "light2",
  animationEnabled: true,
  toolTip:{
    shared: true,
    reversed: true
  },
  axisY: {
    title: "Number of transactions",
  //  suffix: " MW"
  },
  legend: {
    cursor: "pointer",
    itemclick: toggleDataSeries
  },
  axisX:{
      //title: "Axis X with interval 50",
      interval: 1,
      title: "Time"
    },
  data: [
        <?php for($i=0; $i<($result1->num_rows); $i++){ ?>
     
      {    
      type: "stackedColumn",
      name: "<?php echo $storesfortimes[$i]; ?> ",
      showInLegend: true,
      yValueFormatString: "#,##0 transactions",
      dataPoints: <?php echo json_encode($dataPoints[$i], JSON_NUMERIC_CHECK); ?>
    } 
  <?php   if($i!=($result1->num_rows - 1)){ ?>
      ,
  <?php   } 
  } ?>

  ]
});


chart.render();
 
function toggleDataSeries(e) {
  if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
    e.dataSeries.visible = false;
  } else {
    e.dataSeries.visible = true;
  }
  e.chart.render();
}

}
</script>
<body>
<div id="chartContainer" style="height: 370px; width: 50%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>

<?php
}
else{
  echo "No transactions"."<br>";
}
?>

<?php
include "footer.html";
?>